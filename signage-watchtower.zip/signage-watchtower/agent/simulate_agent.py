"""
Simulated mini-PC agent — REAL process, REAL HTTP heartbeats.
Only difference from agent.py (given earlier) is that CPU/RAM/temp/ping
are randomly generated instead of read from psutil, since this process
isn't actually running on a signage PC. The HTTP contract, retry
behaviour, and heartbeat loop are identical to production.

Usage: python3 simulate_agent.py WAL-SCR-04
"""
import random
import sys
import time
from datetime import datetime, timezone

import requests

DASHBOARD_URL = "http://localhost:4000/api/heartbeat"
API_KEY = "demo-secret-key"
SCREEN_ID = sys.argv[1] if len(sys.argv) > 1 else "WAL-SCR-UNKNOWN"
HEARTBEAT_INTERVAL_S = 2.5  # sped up from real 60s so the demo is watchable

# Give a couple of screens a "personality" so you see the alerting logic fire
FAULT_PROFILE = {
    "WAL-SCR-05": "overheat_prone",
    "WAL-CONC-02": "flaky_network",
}.get(SCREEN_ID, "healthy")


def generate_stats(tick: int) -> dict:
    cpu = random.randint(15, 45)
    ram = random.randint(30, 60)
    temp = random.randint(48, 60)
    latency = random.randint(12, 45)
    reasons = []
    status = "green"

    if FAULT_PROFILE == "overheat_prone" and tick % 6 == 0:
        temp = random.randint(78, 88)
        status, reasons = "amber", ["temp_high"]
    if FAULT_PROFILE == "flaky_network" and tick % 7 == 0:
        latency = None
        status, reasons = "red", ["network_unreachable"]

    return {
        "screen_id": SCREEN_ID,
        "site": "walsall",
        "hostname": f"{SCREEN_ID}-host",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "cpu_percent": cpu,
        "ram_percent": ram,
        "cpu_temp_c": temp,
        "latency_ms": latency,
        "status": status,
        "reasons": reasons,
    }


def main():
    print(f"[{SCREEN_ID}] agent starting, profile={FAULT_PROFILE}, posting every {HEARTBEAT_INTERVAL_S}s")
    tick = 0
    while True:
        payload = generate_stats(tick)
        try:
            r = requests.post(
                DASHBOARD_URL,
                headers={"Authorization": f"Bearer {API_KEY}"},
                json=payload,
                timeout=3,
            )
            print(f"[{SCREEN_ID}] POST -> {r.status_code}  status={payload['status']}")
        except requests.RequestException as exc:
            print(f"[{SCREEN_ID}] heartbeat failed: {exc}")

        tick += 1
        time.sleep(HEARTBEAT_INTERVAL_S)


if __name__ == "__main__":
    main()
