"""
Signage Watchtower — Fleet Agent
---------------------------------------------------------------------------
Runs as a background service on every mini-PC driving a TV/menu board.
Every HEARTBEAT_INTERVAL_S seconds it collects lightweight system stats,
pings a reliability target (default: the gateway), optionally grabs a
screenshot, and POSTs the payload to the central dashboard.

Deploy: `pip install -r requirements.txt` then run as a Windows service /
scheduled task at logon (the mini-PCs are Windows-based).

requirements.txt:
    psutil==6.0.0
    requests==2.32.3
    mss==9.0.1        # screenshot capture
    pywin32; sys_platform == 'win32'
"""

import json
import platform
import socket
import time
import uuid
from datetime import datetime, timezone

import psutil
import requests

# --------------------------------------------------------------------------
# CONFIG — override via env vars or a local config.json in production
# --------------------------------------------------------------------------
DASHBOARD_URL = "https://signage.internal.example/api/heartbeat"
SCREEN_ID = socket.gethostname()          # e.g. "WALSALL-SCR-04"
SITE = "walsall"
HEARTBEAT_INTERVAL_S = 60
PING_TARGET = "8.8.8.8"                   # or internal gateway IP
TEMP_WARN_C = 75
SCREENSHOT_EVERY_N_BEATS = 5              # throttle bandwidth use
API_KEY = "REPLACE_ME"


def get_cpu_temp_c() -> float | None:
    """Best-effort CPU temp read; falls back to None on unsupported hardware."""
    try:
        temps = psutil.sensors_temperatures()
        for entries in temps.values():
            if entries:
                return round(entries[0].current, 1)
    except (AttributeError, NotImplementedError):
        pass
    return None


def ping_ms(host: str, timeout_s: float = 2.0) -> float | None:
    """Simple TCP-connect latency check (avoids needing raw ICMP sockets)."""
    start = time.perf_counter()
    try:
        with socket.create_connection((host, 443), timeout=timeout_s):
            return round((time.perf_counter() - start) * 1000, 1)
    except OSError:
        return None


def capture_screenshot_b64() -> str | None:
    try:
        import base64
        from io import BytesIO

        import mss
        from PIL import Image

        with mss.mss() as sct:
            shot = sct.grab(sct.monitors[1])
            img = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")
            img.thumbnail((640, 360))  # keep payload small
            buf = BytesIO()
            img.save(buf, format="JPEG", quality=60)
            return base64.b64encode(buf.getvalue()).decode("ascii")
    except Exception:
        return None


def collect_stats() -> dict:
    cpu_temp = get_cpu_temp_c()
    latency = ping_ms(PING_TARGET)

    status = "green"
    reasons = []
    if latency is None:
        status = "red"
        reasons.append("network_unreachable")
    if psutil.cpu_percent(interval=0.5) > 90:
        status = "amber" if status == "green" else status
        reasons.append("cpu_high")
    if cpu_temp and cpu_temp > TEMP_WARN_C:
        status = "amber" if status == "green" else status
        reasons.append("temp_high")

    return {
        "screen_id": SCREEN_ID,
        "site": SITE,
        "hostname": platform.node(),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "cpu_percent": psutil.cpu_percent(interval=None),
        "ram_percent": psutil.virtual_memory().percent,
        "cpu_temp_c": cpu_temp,
        "latency_ms": latency,
        "uptime_s": int(time.time() - psutil.boot_time()),
        "status": status,
        "reasons": reasons,
        "agent_version": "1.0.0",
    }


def send_heartbeat(payload: dict, screenshot_b64: str | None = None) -> None:
    body = dict(payload)
    if screenshot_b64:
        body["screenshot_b64"] = screenshot_b64

    try:
        requests.post(
            DASHBOARD_URL,
            headers={"Authorization": f"Bearer {API_KEY}"},
            json=body,
            timeout=5,
        )
    except requests.RequestException as exc:
        # Never crash the agent because the dashboard is briefly down —
        # it'll pick up the next heartbeat and the dashboard itself will
        # flag the missed beat as "amber/red" based on last-seen time.
        print(f"[agent] heartbeat post failed: {exc}")


def main() -> None:
    beat_count = 0
    print(f"[agent] starting on {SCREEN_ID} — posting every {HEARTBEAT_INTERVAL_S}s")

    while True:
        stats = collect_stats()

        screenshot = None
        if beat_count % SCREENSHOT_EVERY_N_BEATS == 0:
            screenshot = capture_screenshot_b64()

        send_heartbeat(stats, screenshot)
        print(f"[agent] {stats['timestamp']} status={stats['status']} "
              f"cpu={stats['cpu_percent']}% ram={stats['ram_percent']}% "
              f"latency={stats['latency_ms']}ms")

        beat_count += 1
        time.sleep(HEARTBEAT_INTERVAL_S)


if __name__ == "__main__":
    main()
