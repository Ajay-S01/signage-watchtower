/**
 * Signage Watchtower — Ingestion Server (LIVE, actually running)
 * -----------------------------------------------------------------
 * Same contract as the production version (POST /api/heartbeat,
 * GET /api/screens, WS broadcast), swapping Postgres for a flat
 * JSON file so it runs with zero external services for this demo.
 * Drop-in replace with the pg version (from earlier) for production.
 */
const express = require("express");
const { WebSocketServer } = require("ws");
const { createServer } = require("http");
const fs = require("fs");
const path = require("path");

const DB_FILE = path.join(__dirname, "db.json");
const OFFLINE_AFTER_S = 8; // shortened for the live demo (prod: 180)
const API_KEY = "demo-secret-key";

function loadDb() {
  if (!fs.existsSync(DB_FILE)) return { screens: {}, heartbeats: [] };
  return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
}
function saveDb(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

const app = express();
app.use(express.json({ limit: "2mb" }));
const server = createServer(app);
const wss = new WebSocketServer({ server, path: "/ws" });

function broadcast(event) {
  const msg = JSON.stringify(event);
  wss.clients.forEach((c) => { if (c.readyState === 1) c.send(msg); });
}

app.post("/api/heartbeat", (req, res) => {
  if (req.headers.authorization !== `Bearer ${API_KEY}`) {
    return res.status(401).json({ error: "unauthorized" });
  }
  const { screen_id, site, hostname, status, reasons, cpu_percent, ram_percent, cpu_temp_c, latency_ms } = req.body;
  if (!screen_id) return res.status(400).json({ error: "screen_id required" });

  const db = loadDb();
  db.screens[screen_id] = {
    screen_id, site, hostname, status, reasons,
    cpu_percent, ram_percent, cpu_temp_c, latency_ms,
    last_seen_at: new Date().toISOString(),
  };
  db.heartbeats.push({ screen_id, status, cpu_percent, ram_percent, cpu_temp_c, latency_ms, at: new Date().toISOString() });
  if (db.heartbeats.length > 500) db.heartbeats = db.heartbeats.slice(-500);
  saveDb(db);

  console.log(`[server] heartbeat  ${screen_id.padEnd(16)} status=${status.padEnd(5)} cpu=${cpu_percent}% ram=${ram_percent}% temp=${cpu_temp_c}C ping=${latency_ms ?? "timeout"}`);

  broadcast({ type: "heartbeat", ...db.screens[screen_id] });
  res.status(204).end();
});

app.get("/api/screens", (_req, res) => {
  const db = loadDb();
  const now = Date.now();
  const out = Object.values(db.screens).map((s) => {
    const age = (now - new Date(s.last_seen_at).getTime()) / 1000;
    return { ...s, effective_status: age > OFFLINE_AFTER_S ? "red" : s.status };
  });
  res.json(out);
});

app.get("/api/stats", (_req, res) => {
  const db = loadDb();
  res.json({ total_heartbeats_received: db.heartbeats.length, screens_known: Object.keys(db.screens).length });
});

setInterval(() => {
  const db = loadDb();
  const now = Date.now();
  let changed = false;
  for (const s of Object.values(db.screens)) {
    const age = (now - new Date(s.last_seen_at).getTime()) / 1000;
    if (age > OFFLINE_AFTER_S && s.status !== "red") {
      s.status = "red";
      s.reasons = ["missed_heartbeat"];
      changed = true;
      console.log(`[server] \u26a0 ${s.screen_id} went silent \u2014 marking RED`);
      broadcast({ type: "offline", screen_id: s.screen_id });
    }
  }
  if (changed) saveDb(db);
}, 2000);

const PORT = 4000;
server.listen(PORT, () => console.log(`[server] LIVE and listening on http://localhost:${PORT}`));
