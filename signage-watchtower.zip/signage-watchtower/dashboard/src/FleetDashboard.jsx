import { useEffect, useMemo, useState } from "react";

const STATUS_STYLE = {
  green: { dot: "bg-signal-ok", ring: "ring-signal-ok/30", label: "Online" },
  amber: { dot: "bg-signal-warn", ring: "ring-signal-warn/30", label: "Degraded" },
  red: { dot: "bg-[#FF4D4D]", ring: "ring-[#FF4D4D]/30", label: "Offline / Alert" },
  unknown: { dot: "bg-[#4A4A55]", ring: "ring-[#4A4A55]/30", label: "Unknown" },
};

export default function FleetDashboard() {
  const [screens, setScreens] = useState([]);
  const [filterSite, setFilterSite] = useState("all");

  // Initial load
  useEffect(() => {
    fetch("/api/screens").then((r) => r.json()).then(setScreens);
  }, []);

  // Live updates
  useEffect(() => {
    const ws = new WebSocket(`${location.origin.replace("http", "ws")}/ws`);
    ws.onmessage = (evt) => {
      const msg = JSON.parse(evt.data);
      setScreens((prev) =>
        prev.map((s) =>
          s.screen_id === msg.screen_id
            ? { ...s, ...msg, effective_status: msg.status ?? "red" }
            : s
        )
      );
    };
    return () => ws.close();
  }, []);

  const sites = useMemo(
    () => ["all", ...new Set(screens.map((s) => s.site))],
    [screens]
  );

  const visible = screens.filter(
    (s) => filterSite === "all" || s.site === filterSite
  );

  const counts = visible.reduce(
    (acc, s) => ({ ...acc, [s.effective_status]: (acc[s.effective_status] ?? 0) + 1 }),
    {}
  );

  return (
    <div className="min-h-screen bg-[#0A0A0D] text-[#F2F2F5] p-6">
      <header className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="font-display text-2xl font-bold">Signage Watchtower</h1>
          <p className="text-[#8C8C99] text-sm">{visible.length} screens monitored</p>
        </div>

        <div className="flex items-center gap-4">
          <SummaryPill status="green" count={counts.green ?? 0} />
          <SummaryPill status="amber" count={counts.amber ?? 0} />
          <SummaryPill status="red" count={counts.red ?? 0} />

          <select
            value={filterSite}
            onChange={(e) => setFilterSite(e.target.value)}
            className="bg-[#131318] border border-[#24242C] rounded-sm px-3 py-1.5 text-sm"
          >
            {sites.map((site) => (
              <option key={site} value={site}>{site}</option>
            ))}
          </select>
        </div>
      </header>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
        {visible.map((screen) => (
          <ScreenTile key={screen.screen_id} screen={screen} />
        ))}
      </div>
    </div>
  );
}

function ScreenTile({ screen }) {
  const style = STATUS_STYLE[screen.effective_status] ?? STATUS_STYLE.unknown;
  const lastSeen = screen.last_seen_at
    ? new Date(screen.last_seen_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    : "—";

  return (
    <div className={`border border-[#24242C] bg-[#131318] rounded-sm p-4 ring-1 ${style.ring}`}>
      <div className="flex items-center justify-between mb-3">
        <span className="font-display font-semibold text-sm truncate">{screen.screen_id}</span>
        <span className={`w-2 h-2 rounded-full ${style.dot}`} />
      </div>

      {screen.screenshot_url ? (
        <img
          src={screen.screenshot_url}
          alt=""
          className="w-full aspect-video object-cover rounded-sm mb-3 border border-[#24242C]"
        />
      ) : (
        <div className="w-full aspect-video rounded-sm mb-3 border border-[#24242C] flex items-center justify-center text-[#4A4A55] text-xs">
          no preview
        </div>
      )}

      <dl className="space-y-1 text-xs text-[#8C8C99]">
        <Row label="CPU" value={screen.cpu_percent != null ? `${screen.cpu_percent}%` : "—"} />
        <Row label="RAM" value={screen.ram_percent != null ? `${screen.ram_percent}%` : "—"} />
        <Row label="Ping" value={screen.latency_ms != null ? `${screen.latency_ms}ms` : "—"} />
        <Row label="Last seen" value={lastSeen} />
      </dl>

      {screen.reasons?.length > 0 && (
        <p className="mt-2 text-[10px] text-[#FF4D4D]">{screen.reasons.join(", ")}</p>
      )}
    </div>
  );
}

function Row({ label, value }) {
  return (
    <div className="flex justify-between">
      <dt>{label}</dt>
      <dd className="text-[#C9C9D1]">{value}</dd>
    </div>
  );
}

function SummaryPill({ status, count }) {
  const style = STATUS_STYLE[status];
  return (
    <span className="flex items-center gap-1.5 text-xs font-display tracking-wide">
      <span className={`w-2 h-2 rounded-full ${style.dot}`} />
      {count} {style.label}
    </span>
  );
}
